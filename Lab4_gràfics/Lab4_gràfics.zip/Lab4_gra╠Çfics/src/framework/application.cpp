#include "application.h"
#include "utils.h"
#include "includes.h"
#include "utils.h"

#include "image.h"
#include "mesh.h"
#include "shader.h"
#include "texture.h"
#include "camera.h"
#include "material.h"
#include "light.h"

Camera* camera = NULL;
Mesh* mesh = NULL;
Shader* shader = NULL;

// MATERIAL //
Material* material = NULL;
std::vector<Material*>materials;

// LIGHTS //
Light* light = NULL;
std::vector<Light*> lights;
Vector3 ambient_light(0.1,0.2,0.3); //here we can store the global ambient light of the scene

// SHADERS //
Shader* phong_shader = NULL;
Shader* gouraud_shader = NULL;

// PEOPLE //
std::vector<Matrix44> mesh_of_people;

float angle = 0;

Application::Application(const char* caption, int width, int height)
{
    this->window = createWindow(caption, width, height);

    // initialize attributes
    // Warning: DO NOT CREATE STUFF HERE, USE THE INIT
    // things create here cannot access opengl
    int w,h;
    SDL_GetWindowSize(window,&w,&h);

    this->window_width = w;
    this->window_height = h;
    this->keystate = SDL_GetKeyboardState(NULL);
}

//Here we have already GL working, so we can create meshes and textures
void Application::init(void)
{
    std::cout << "initiating app..." << std::endl;

    //here we create a global camera and set a position and projection properties
    camera = new Camera();
    camera->lookAt(Vector3(0,20,20),Vector3(0,10,0),Vector3(0,1,0));
    camera->setPerspective(60,window_width / window_height,0.1,10000);

    //then we load a mesh
    mesh = new Mesh();
    if( !mesh->loadOBJ( "../res/meshes/lee.obj" ) )
        std::cout << "FILE Lee.obj NOT FOUND " << std::endl;

    //we load one or several shaders...
    shader = Shader::Get( "../res/shaders/simple.vs", "../res/shaders/simple.fs" );

    //load your Gouraud and Phong shaders here and stored them in some global variables
    gouraud_shader = Shader::Get("../res/shaders/gouraud.vs", "../res/shaders/gouraud.fs");
    phong_shader = Shader::Get("../res/shaders/phong.vs", "../res/shaders/phong.fs");

    // MATERIALS //

    //Creem els materials
    material = new Material();
    materials.resize(6);
    for (int i = 0; i < materials.size(); i++) {
        materials[i] = new Material();
    }

    // Pearl
    materials[0]->ambient.set(0.25, 0.20725, 0.20725);
    materials[0]->diffuse.set(1., 0.829, 0.829);
    materials[0]->specular.set(0.296648, 0.296648, 0.296648);
    materials[0]->shininess = 0.1;

    // Ruby
    materials[1]->ambient.set(0.1745, 0.01175, 0.01175);
    materials[1]->diffuse.set(0.61424, 0.04136, 0.04136);
    materials[1]->specular.set(0.727811, 0.626959, 0.626959);
    materials[1]->shininess = 0.5;

    // Bronze
    materials[2]->ambient.set(0.2125, 0.1275, 0.054);
    materials[2]->diffuse.set(0.714, 0.4284, 0.18144);
    materials[2]->specular.set(0.393548, 0.271906, 0.166721);
    materials[2]->shininess = 0.2;

    // Gold
    materials[3]->ambient.set(0.24725, 0.1995, 0.0745);
    materials[3]->diffuse.set(0.75164, 0.60648, 0.22648);
    materials[3]->specular.set(0.628281, 0.555802, 0.366065);
    materials[3]->shininess = 0.4;

    // Silver
    materials[4]->ambient.set(0.19225, 0.19225, 0.19225);
    materials[4]->diffuse.set(0.50754, 0.50754, 0.50754);
    materials[4]->specular.set(0.508273, 0.508273, 0.508273);
    materials[4]->shininess = 0.4;

    // Turquoise
    materials[5]->ambient.set(0.1, 0.18725, 0.1745);
    materials[5]->diffuse.set(0.396, 0.74151, 0.60102);
    materials[5]->specular.set(0.297254, 0.30829, 0.306678);
    materials[5]->shininess = 0.6;

    // LIGHTS //

    light = new Light();
    lights.resize(3);
    for (int i = 0; i < lights.size(); i++) {
        lights[i] = new Light();
    }

    // Creem llums random (que ens agradin) - Nosaltres, RGB
    lights[0]->position.set(-50, 0, 10);
    lights[1]->position.set(0, 50, 25);
    lights[2]->position.set(50, 0, -10);

    lights[0]->diffuse_color.set(1.f, 0, 0.1f);
    lights[1]->diffuse_color.set(0.2f, 0.5f, 0);
    lights[2]->diffuse_color.set(0, 0.7f, 1.f);

    lights[0]->specular_color.set(0.5f, 1.f, 0);
    lights[1]->specular_color.set(0 , 0.5f,0.8f);
    lights[2]->specular_color.set(1.f, 0, 0.8f);

    // PEOPLE //

    // Creem les meshes
    mesh_of_people.resize(6);
    Matrix44 aux;
    // Inicialitzem
    for (int i = 0; i < mesh_of_people.size(); i++) {
        mesh_of_people[i] = aux;
        mesh_of_people[i].setIdentity();
    }

    // Les coloquem a gust personal
    mesh_of_people[0].rotate(angle,Vector3(0, 1, 0));
    mesh_of_people[0].translate(-13,0,-20);

    mesh_of_people[1].rotate(angle-(M_PI/14), Vector3(0, 1, 0));
    mesh_of_people[1].translate(0, 0, -30);

    mesh_of_people[2].rotate(angle-(M_PI/12), Vector3(0, 1, 0));
    mesh_of_people[2].translate(13,0, -40);

    mesh_of_people[3].rotate(angle-(M_PI/10), Vector3(0, 1, 0));
    mesh_of_people[3].translate(26, 0, -50);

    mesh_of_people[4].rotate(angle-(M_PI/8), Vector3(0, 1, 0));
    mesh_of_people[4].translate(39, 0, -60);

    mesh_of_people[5].rotate(angle-(M_PI/6), Vector3(0, 1, 0));
    mesh_of_people[5].translate(52, 0, -70);
}

//render one frame
void Application::render(void)
{
    //update the aspect of the camera acording to the window size
    camera->aspect = window_width / window_height;
    camera->updateProjectionMatrix();
    //Get the viewprojection matrix from our camera
    Matrix44 viewprojection = camera->getViewProjectionMatrix();

    //set the clear color of the colorbuffer as the ambient light so it matches
    glClearColor(ambient_light.x, ambient_light.y, ambient_light.z, 1.0);

    // Clear the window and the depth buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //clear framebuffer and depth buffer
    glEnable( GL_DEPTH_TEST ); //enable depth testing for occlusions
    glDepthFunc(GL_LEQUAL); //Z will pass if the Z is LESS or EQUAL to the Z of the pixel

    //Inicialitzem la matriu model (ja donada pel codi).
    Matrix44 model_matrix;
    model_matrix.setIdentity();
    model_matrix.translate(0,0,0); //example of translation
    model_matrix.rotate(angle, Vector3(0, 1, 0));

    //Creem totes les condicions possibles per les diferents tasques demanades.
    if(render_task == original){
        Original(model_matrix, viewprojection, window);
    }
    else if(render_task == gouraud){
        Gouraud(model_matrix, viewprojection, window);
    }
    else if(render_task == phong){
        Phong(model_matrix, viewprojection, window);
    }
    else if(render_task == multiple_lights){
        Lights(model_matrix, viewprojection, window);
    }
    else if(render_task == meshes){
        Meshes(model_matrix, viewprojection, window);
    }
    else if(render_task == materials_mesh){
        Materials(model_matrix, viewprojection, window);
    }
}

//called after render
/*DIFERENT TASQUES
 TECLA 1: Il·luminació Gouraud.
 TECLA 2: Il·luminació Phong.
 TECLA 3: Il·luminació múltiple.
 TECLA 4: Múltiples figures.
 TECLA 5: Múltiples figures amb diferents materials*/
void Application::update(double seconds_elapsed)
{
    if(keystate[SDL_SCANCODE_0])
        render_task = original;
    else if(keystate[SDL_SCANCODE_1])
        render_task = gouraud;
    else if(keystate[SDL_SCANCODE_2])
        render_task = phong;
    else if(keystate[SDL_SCANCODE_3])
        render_task = multiple_lights;
    else if(keystate[SDL_SCANCODE_4])
        render_task = meshes;
    else if(keystate[SDL_SCANCODE_5])
        render_task = materials_mesh;

    // ANGLE
    if (keystate[SDL_SCANCODE_X])
        angle += seconds_elapsed;
    else if (keystate[SDL_SCANCODE_Z])
        angle -= seconds_elapsed;

    // EYE MOVEMENT
    if (keystate[SDL_SCANCODE_RIGHT])
        camera->eye = camera->eye + Vector3(1, 0, 0) * seconds_elapsed * 10.0;
    else if (keystate[SDL_SCANCODE_LEFT])
        camera->eye = camera->eye + Vector3(-1, 0, 0) * seconds_elapsed * 10.0;
    if (keystate[SDL_SCANCODE_UP])
        camera->eye = camera->eye + Vector3(0, 1, 0) * seconds_elapsed * 10.0;
    else if (keystate[SDL_SCANCODE_DOWN])
        camera->eye = camera->eye + Vector3(0, -1, 0) * seconds_elapsed * 10.0;

    // ORBIT MOVEMENT - CAMERA
    if (keystate[SDL_SCANCODE_O])
        camera->rotate_eye(seconds_elapsed, Vector3(0, 1, 0));
    else if(keystate[SDL_SCANCODE_P])
        camera->rotate_eye(seconds_elapsed, Vector3(0, -1, 0));
    else if(keystate[SDL_SCANCODE_K])
        camera->rotate_eye(seconds_elapsed, Vector3(1, 0, 0));
    else if(keystate[SDL_SCANCODE_L])
        camera->rotate_eye(seconds_elapsed, Vector3(-1, 0, 0));

    // CENTER MOVEMENT - W, A, S, D
    if (keystate[SDL_SCANCODE_W])
        camera->center.y += 10 * seconds_elapsed;
    if (keystate[SDL_SCANCODE_A])
        camera->center.x -= 10 * seconds_elapsed;
    if (keystate[SDL_SCANCODE_S])
        camera->center.y -= 10 * seconds_elapsed;
    if (keystate[SDL_SCANCODE_D])
        camera->center.x += 10 * seconds_elapsed;

    // FOV MOVEMENT - F, G
    if (keystate[SDL_SCANCODE_F])
        camera->fov -= 10 * seconds_elapsed;
    if (keystate[SDL_SCANCODE_G])
        camera->fov += 10 * seconds_elapsed;

    // SINGLE LIGHT for ex 1,2,4
    // LIGHT MOVEMENT B, H, N, M
    if (keystate[SDL_SCANCODE_B])
        light->position.x -= seconds_elapsed * 40.0;
    else if (keystate[SDL_SCANCODE_M])
        light->position.x += seconds_elapsed * 40.0;
    if (keystate[SDL_SCANCODE_H])
        light->position.y += seconds_elapsed * 40.0;
    else if (keystate[SDL_SCANCODE_N])
        light->position.y -= seconds_elapsed * 40.0;

    // MULTIPLE LIGHT for ex 3
    // LIGHT MOVEMENT Y, U, J, I
    if(keystate[SDL_SCANCODE_Y]){
        for(int i = 0; i < lights.size(); i++){
            lights[i]->position.x -= seconds_elapsed * 40.0;
        }
    }
    else if(keystate[SDL_SCANCODE_I]){
        for(int i = 0; i < lights.size(); i++){
            lights[i]->position.x += seconds_elapsed * 40.0;
        }
    }
    if(keystate[SDL_SCANCODE_U]){
        for(int i = 0; i < lights.size(); i++){
            lights[i]->position.y += seconds_elapsed * 40.0;
        }
    }
    else if(keystate[SDL_SCANCODE_J]){
        for(int i = 0; i < lights.size(); i++){
            lights[i]->position.y -= seconds_elapsed * 40.0;
        }
    }

    // FIRE EFFECT for ex 1,2,4
    if (keystate[SDL_SCANCODE_C]) {
        int rand_sign = 2 * (rand() % 2) - 1 ; // -1 o 1
        if (int(seconds_elapsed) % 200 == 0) {
            for (int i = 0; i < lights.size(); i++) {
                light->position.x += seconds_elapsed * 100 * rand_sign;
                light->position.y += seconds_elapsed * 100 * rand_sign;
                light->position.z += seconds_elapsed * 100 * rand_sign;
            }
        }
    }
}

//keyboard press event
void Application::onKeyPressed( SDL_KeyboardEvent event )
{
    switch(event.keysym.sym)
    {
        case SDLK_ESCAPE: exit(0); break; //ESC key, kill the app
        case SDLK_r:
            Shader::ReloadAll();
            break; //ESC key, kill the app

        // LIGHT CONTROL (exs 1,2,4)
        case SDLK_6:
            // per defecte
            light = new Light();
            break;
            // altres llums
        case SDLK_7: // R
            light = lights[0];
            break;
        case SDLK_8: // G
            light = lights[1];
            break;
        case SDLK_9: // B
            light = lights[2];
            break;
    }
}

//mouse button event
void Application::onMouseButtonDown( SDL_MouseButtonEvent event )
{
    if (event.button == SDL_BUTTON_LEFT) //left mouse pressed
    {
    }
}

void Application::onMouseButtonUp( SDL_MouseButtonEvent event )
{
    if (event.button == SDL_BUTTON_LEFT) //left mouse unpressed
    {
    }
}

//when the app starts
void Application::start()
{
    std::cout << "launching loop..." << std::endl;
    launchLoop(this);
}

void Application::Original(Matrix44 model_matrix, Matrix44 viewprojection, SDL_Window* window){
    //Habilitem el shader original.
    shader->enable();

    //Declarem el model i viewprojection de la matriu.
    shader->setMatrix44("model", model_matrix); //upload the transform matrix to the shader
    shader->setMatrix44("viewprojection", viewprojection); //upload viewprojection info to the shader

    //do the draw call into the GPU
    mesh->render(GL_TRIANGLES);

    //disable shader when we do not need it any more
    shader->disable();

    //swap between front buffer and back buffer
    SDL_GL_SwapWindow(this->window);

}

void Application::Gouraud(Matrix44 model_matrix, Matrix44 viewprojection, SDL_Window *window) {
    //Habilitem el shader gouraud.
    gouraud_shader->enable();

    //Declarem el model i viewprojection de la matriu gouraud.
    gouraud_shader->setMatrix44("model", model_matrix);
    gouraud_shader->setMatrix44("viewprojection", viewprojection);

    // CAMERA //
    gouraud_shader->setUniform3("camera", camera->eye);

    // LIGHTS //
    gouraud_shader->setUniform3("light", light->position);
    gouraud_shader->setUniform3("Id", light->diffuse_color);
    gouraud_shader->setUniform3("Is", light->specular_color);
    gouraud_shader->setUniform3("Ia", ambient_light);

    // MATERIAL//
    gouraud_shader->setUniform3("Ka", material->ambient);
    gouraud_shader->setUniform3("Kd", material->diffuse);
    gouraud_shader->setUniform3("Ks", material->specular);
    gouraud_shader->setFloat("alpha", material->shininess);

    //do the draw call into the GPU
    mesh->render(GL_TRIANGLES);

    //disable shader when we do not need it any more
    gouraud_shader->disable();

    //swap between front buffer and back buffer
    SDL_GL_SwapWindow(this->window);
}

void Application::Phong(Matrix44 model_matrix, Matrix44 viewprojection, SDL_Window *window) {
    //Habilitem el shader Phong.
    phong_shader->enable();

    //Declarem el model i viewprojection de la matriu Phong.
    phong_shader->setMatrix44("model", model_matrix);
    phong_shader->setMatrix44("viewprojection", viewprojection);

    // CAMERA //
    phong_shader->setUniform3("camera", camera->eye);

    // LIGHTS //
    phong_shader->setUniform3("light", light->position);
    phong_shader->setUniform3("Id", light->diffuse_color);
    phong_shader->setUniform3("Is", light->specular_color);
    phong_shader->setUniform3("Ia", ambient_light);

    // MATERIAL //
    phong_shader->setUniform3("Ka", material->ambient);
    phong_shader->setUniform3("Kd", material->diffuse);
    phong_shader->setUniform3("Ks", material->specular);
    phong_shader->setFloat("alpha", material->shininess);

    //do the draw call into the GPU
    mesh->render(GL_TRIANGLES);

    //disable shader when we do not need it any more
    phong_shader->disable();

    //swap between front buffer and back buffer
    SDL_GL_SwapWindow(this->window);
}

void Application::Lights(Matrix44 model_matrix, Matrix44 viewprojection, SDL_Window *window) {
    //Per fer la tasca de múltiple light, utilitzem l'algoritme d'il·luminació Phong. Per tant, habilitem el shader Phong.
    phong_shader->enable();

    //Declarem el model i viewprojection de la matriu Phong.
    phong_shader->setMatrix44("model", model_matrix);
    phong_shader->setMatrix44("viewprojection", viewprojection);

    // CAMERA //
    phong_shader->setUniform3("camera", camera->eye);

    // LIGHTS //
    phong_shader->setUniform3("Ia", ambient_light);

    // MATERIAL //
    phong_shader->setUniform3("Ka", material->ambient);
    phong_shader->setUniform3("Kd", material->diffuse);
    phong_shader->setUniform3("Ks", material->specular);
    phong_shader->setFloat("alpha", material->shininess);

    //Com volem tres llums, utilitzem un for per inicialitzar-les i declarar les seves respectives direccions, colors i intensitats.
    for(int i = 0; i < lights.size(); i++){
        phong_shader->setUniform3("light", lights[i]->position);
        phong_shader->setUniform3("Id", lights[i]->diffuse_color);
        phong_shader->setUniform3("Is", lights[i]->specular_color);
        if(i == 0){
            glDisable(GL_BLEND);
            mesh->render(GL_TRIANGLES);
        }
        else{
            glEnable(GL_BLEND);
            glBlendFunc(GL_ONE, GL_ONE);
            mesh->render(GL_TRIANGLES);
        }
    }
    //disable shader when we do not need it any more
    phong_shader->disable();

    //swap between front buffer and back buffer
    SDL_GL_SwapWindow(window);

    glDisable(GL_BLEND);
}

void Application::Meshes(Matrix44 model_matrix, Matrix44 viewprojection, SDL_Window *window) {
    //Per la tasca de múltiples figures, també utilitzem l'algoritme d'il·luminació Phong.
    phong_shader->enable();

    //Declarem el model i viewprojection de la matriu Phong.
    phong_shader->setMatrix44("model", model_matrix);
    phong_shader->setMatrix44("viewprojection", viewprojection);

    // CAMERA //
    phong_shader->setUniform3("camera", camera->eye);

    // LIGHTS //
    phong_shader->setUniform3("light", light->position);
    phong_shader->setUniform3("Id", light->diffuse_color);
    phong_shader->setUniform3("Is", light->specular_color);
    phong_shader->setUniform3("Ia", ambient_light);

    // MATERIAL & PEOPLE //
    //Per la mida de l'array de persones, declarem per cada figura el material ambient, difusió, especulació i brillantor.
    for(int i = 0; i < mesh_of_people.size(); i++){
        phong_shader->setUniform3("Ka", material->ambient);
        phong_shader->setUniform3("Kd", material->diffuse);
        phong_shader->setUniform3("Ks", material->specular);
        phong_shader->setFloat("alpha", material->shininess);
        phong_shader->setMatrix44("model", mesh_of_people[i]);
        mesh->render(GL_TRIANGLES);
    }
    //disable shader when we do not need it any more
    phong_shader->disable();

    //swap between front buffer and back buffer
    SDL_GL_SwapWindow(window);
}

void Application::Materials(Matrix44 model_matrix, Matrix44 viewprojection, SDL_Window* window){
    //Per la tasca de múltiples figures amb diferents materials, utilitzem l'algoritme d'il·luminació Phong.
    phong_shader->enable();

    //Declarem el model i viewprojection de la matriu Phong.
    phong_shader->setMatrix44("model", model_matrix);
    phong_shader->setMatrix44("viewprojection", viewprojection);

    // CAMERA //
    phong_shader->setUniform3("camera", camera->eye);

    // LIGHTS //
    phong_shader->setUniform3("light", light->position);
    phong_shader->setUniform3("Id", light->diffuse_color);
    phong_shader->setUniform3("Is", light->specular_color);
    phong_shader->setUniform3("Ia", ambient_light);

    // MATERIAL & PEOPLE //

    glDisable(GL_BLEND);

    //Les nostres llistes de materials i mesh_of_people tenen la mateixa mida, per tant, declarem amb un for un material
    //diferent per cada figura.
    for(int i = 0; i < materials.size(); i++){
        phong_shader->setUniform3("Ka", materials[i]->ambient);
        phong_shader->setUniform3("Kd", materials[i]->diffuse);
        phong_shader->setUniform3("Ks", materials[i]->specular);
        phong_shader->setFloat("alpha", materials[i]->shininess);
        phong_shader->setMatrix44("model", mesh_of_people[i]);
        mesh->render(GL_TRIANGLES);
    }
    //disable shader when we do not need it any more
    phong_shader->disable();

    //swap between front buffer and back buffer
    SDL_GL_SwapWindow(window);
}