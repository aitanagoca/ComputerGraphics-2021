#!/bin/bash

zip -r computergraphics.zip . -x *.vscode* -x *build* -x *.git*
