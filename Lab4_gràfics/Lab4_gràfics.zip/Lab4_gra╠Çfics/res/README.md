Aitana González Cárdenas - NIA: 240783 - aitana.gonzalez01@estudiant.upf.edu

Álvaro Jiménez Barreno - NIA: 240903 - alvaro.jimenez06@estudiant.upf.edu

# Information

Funcionament:

Una vegada posem en marxa l'aplicació (premem el botó de "run", recomanant el mode release), es mostrarà el framebuffer en blau fosc.
Seguidament, si premem les tecles utilitzades per fer funcionar l'aplicació, podrem observar...

Tecles emprades:

- Tecla "0": Original Shader.
- Tecla "1": Tasca 1. Gouraud Shader.
- Tecla "2": Tasca 2. Phong Shader.
- Tecla "3": Tasca 3. Phong Shader with Multiple Lights.
- Tecla "4": Tasca 4. Multiple Mesh Phong Shader.
- Tecla "5": Multiple Mesh Phong Shader with different Materials.

-- For tasks 1, 2 & 4 -- 
- Tecla "6": Change to default light.
- Tecla "7": Change to lights[1] - red.
- Tecla "8": Change to lights[2] - green.
- Tecla "9": Change to lights[3] - blue.

Observacions:

Per dur a terme l'objectiu de la pràctica, utilitzem les tecles enumerades anteriorment per canviar entre modes.
A més, per realitzar la interactivitat entre l'ususari i el programa, utilitzem les següents tecles:

-- Eye: posició on es col·loca la "càmera" --

- Tecla "Left Arrow": Eye position (direccionem el punt de visió cap a la dreta).
- Tecla "Right Arrow": Eye position (direccionem el punt de visió cap a l'esquerra).
- Tecla "Up Arrow": Eye position (direccionem el punt de visió cap a dalt).
- Tecla "Down Arrow": Eye position (direccionem el punt de visió cap abaix).
  
-- Fov: angle de visió de la càmera --

- Tecla "F": Eye position (allunyem).
- Tecla "G": Eye position (apropem).

-- Center: posició a la qual apunta la "càmera" --

- Tecla "A": Center position (desplacem cap a la dreta).
- Tecla "D": Center position (desplacem cap a l'esquerra).
- Tecla "W": Center position (desplacem cap abaix).
- Tecla "S": Center position (desplacem cap a dalt).

-- Angle: radians que desplacem la mesh --

- Tecla "Z": Girem x radians cap a l'esquerra.
- Tecla "X": Girem x radians cap a la dreta.

-- Orbit camera around the mesh: movem eye, centre fixat --

- Tecla "O": Orbitem cap a l'esquerra.
- Tecla "P": Orbitem cap a la dreta.
- Tecla "K": Orbitem cap a dalt.
- Tecla "L": Orbitem cap abaix.

-- Desplaçament llum --

// SINGLE LIGHT //
- Tecla "B": Desplacem la llum cap a l'esquerra.
- Tecla "M": Desplacem la llum cap a la dreta.
- Tecla "H": Desplacem la llum cap a dalt.
- Tecla "N": Desplacem la llum cap abaix.

// MULTIPLE LIGHT //
- Tecla "Y": Desplacem les llums cap a l'esquerra.
- Tecla "I": Desplacem les llums cap a la dreta.
- Tecla "U": Desplacem les llums cap a dalt.
- Tecla "J": Desplacem les llums cap abaix.

- Tecla "C": Fire Effect.

  

